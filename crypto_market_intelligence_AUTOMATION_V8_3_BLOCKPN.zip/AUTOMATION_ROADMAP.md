# Crypto Market Intelligence — Automation roadmap

## V1 — live automation
The deployment automates the core sales loop:

**product → checkout → server-side payment verification → signed entitlement → protected CSV delivery → dashboard → optional email**

Supported payment routes:
- Mollie (primary)
- PayLio
- Direct crypto MVP

The customer never receives the private `data/*.csv.gz` files directly. Downloads are streamed through `/api/download` only after a valid signed entitlement.

## Current hardening
- Mollie checkout no longer forces `creditcard`; Mollie can present the payment methods enabled for the merchant.
- `/api/health` provides a safe deployment/configuration check without exposing secrets.
- `ORDER_SECRET` signs and verifies access tokens.
- Payment API keys stay in Vercel environment variables and are never placed in `public/`.

## V2 — durable automation
Next step is persistent order storage (for example Postgres/Neon) for:
- order/payment records
- entitlement history and revocation
- customer dashboard history
- sales/product analytics
- reliable email-delivery state and idempotency
- automated AI-generated post-purchase reports

Do not add mass unsolicited outreach automation. Use only contacts/channels for which the applicable lawful basis and marketing permissions exist.

## V8 — durable sales automation
V8 adds optional Neon/Postgres persistence for paid orders, delivery state, email state, download counts and product analytics. It also adds a protected admin control center with an 8-hour signed session. Payment webhooks remain the source of truth and the database is used for history, idempotent order recording and analytics.

Required for V8 persistence:
- `DATABASE_URL` (or `POSTGRES_URL`) — Neon/Postgres connection string
- `ADMIN_KEY` — private admin login secret

The system remains functional without the database, but persistence/analytics are disabled until the database variable is configured.
