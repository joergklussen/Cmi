# CMI Automation V7

- Shoppex webhook now supports one primary secret plus optional additional secrets via `SHOPPEX_WEBHOOK_SECRETS`.
- Timestamped HMAC-SHA256 webhook signatures are validated with replay tolerance.
- Existing raw-HMAC compatibility is retained for webhook configurations that send a plain digest.
- Product mapping and server-side paid-order verification remain unchanged.
- Secrets remain server-side only.
