# SellAuth Dynamic Delivery

Dynamic Delivery URL for all five CMI SellAuth products:

`https://cryptomarketintelligence.pro/api/sellauth-dynamic`

Environment variable required in Vercel:

`SELLAUTH_WEBHOOK_SECRET=<SellAuth Storefront > Configure > Miscellaneous secret>`

Product/variant mapping:

- 869944 / 1607572 -> test -> 100 leads
- 869945 / 1607573 -> starter -> 1,000 leads
- 869946 / 1607574 -> advanced -> 10,000 leads
- 869947 / 1607575 -> pro -> 25,000 leads
- 869948 / 1607576 -> business -> 115,000 leads

The endpoint verifies `X-Signature` using HMAC-SHA256 over the raw POST body and responds with HTTP 200 plus a plain-text signed download URL.

## Payment selection

The customer-facing checkout is explicitly a three-way selection:

1. Mollie
2. PayLio
3. Direct Crypto

The frontend passes the selected provider to `/api/pay`; Direct Crypto continues to `/crypto-pay.html` after the customer selects a coin.

Shoppex and Sellix integrations remain separate and are not removed by the SellAuth integration.
