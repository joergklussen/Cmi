# Blockpn setup for CMI

The checkout now supports Blockpn as the fourth payment method. The backend creates a one-time Blockpn hosted payment and fulfills only after a verified `payment.paid` webhook. Blockpn recommends server-side API calls, idempotency, signed webhooks, and using the webhook/API status as the fulfillment signal.

## Vercel environment variables

Set these in the Vercel project:

- `BLOCKPN_API_KEY` = your Blockpn merchant API key
- `BLOCKPN_WEBHOOK_SECRET` = the signing secret for the webhook
- `BLOCKPN_PAYMENT_MODE` = `live` for production (optional; defaults to `live`)

Do not put the API key in frontend code.

## Blockpn webhook

Webhook URL:

`https://cryptomarketintelligence.pro/api/blockpn-webhook`

Enable at least:

- `payment.paid`
- `payment.expired`

The endpoint verifies `X-Signature` and `X-Webhook-Timestamp` and uses the raw request body.

## Flow

1. Customer selects **Blockpn** in `/checkout`.
2. CMI creates a EUR payment with `accept: all`, customer email, a signed order reference, return URL, webhook URL and metadata.
3. Customer is redirected to Blockpn's hosted checkout.
4. Blockpn sends a signed `payment.paid` webhook.
5. CMI records the paid order and creates the normal signed CMI download/dashboard token.
6. The return page can show the access immediately when the webhook record is already durable; otherwise it shows a processing message.

The implementation deliberately does not release the product solely because the customer reached the return URL.
