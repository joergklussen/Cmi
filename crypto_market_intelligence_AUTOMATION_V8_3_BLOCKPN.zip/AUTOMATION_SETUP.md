# CMI Automation — Vercel

## Production environment

Required:
- `APP_BASE_URL=https://cryptomarketintelligence.pro`
- `ORDER_SECRET=<long random secret>`
- `MOLLIE_API_KEY=<Mollie live API key>`

For PayLio:
- `PAYLIO_API_KEY=<current live API key>`
- `PAYLIO_WALLET_ADDRESS=<payout wallet>`

Optional email delivery:
- `RESEND_API_KEY=<Resend API key>`
- `FROM_EMAIL=<verified sender>`

Never commit any API key or secret to GitHub or `public/`.

## Automated sales flow

1. Customer selects a product.
2. Checkout asks for the email address.
3. Customer chooses Mollie, PayLio or Direct Crypto.
4. Mollie/PayLio payments are verified server-to-server.
5. A signed 30-day entitlement is generated only after a confirmed payment.
6. The protected download endpoint streams the matching CSV.
7. The dashboard is opened with the same signed entitlement.
8. If Resend is configured, confirmed PayLio/Mollie payments can trigger delivery email.

## Mollie

Mollie is the primary hosted checkout. The integration intentionally does **not** force `creditcard`, so the payment methods enabled for the Mollie account can be offered by Mollie's checkout.

## Deployment check

Open `/api/health` after deployment. It reports only whether required environment variables are present; it never returns their values.

## Data protection

The lead data may contain personal information. Sales, delivery, marketing and outreach must comply with applicable privacy, data-protection and anti-spam rules. The system does not automatically send unsolicited outreach to purchased leads.
