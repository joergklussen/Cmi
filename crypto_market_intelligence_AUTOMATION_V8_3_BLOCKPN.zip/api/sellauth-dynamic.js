import crypto from 'node:crypto';
import { PRODUCTS, safeEmail, signPayload } from './_lib.js';
import { getDynamicDelivery, saveDynamicDelivery, recordOrder } from './_db.js';

export const config = { api: { bodyParser: false } };

// SellAuth Product ID -> CMI product key
const PRODUCT_IDS = {
  '869944': 'test',
  '869945': 'starter',
  '869946': 'advanced',
  '869947': 'pro',
  '869948': 'business'
};

// SellAuth Variant ID -> CMI product key (kept explicit so variants cannot be mixed up)
const VARIANT_IDS = {
  '1607572': 'test',
  '1607573': 'starter',
  '1607574': 'advanced',
  '1607575': 'pro',
  '1607576': 'business'
};

function rawBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c)));
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function verifySignature(req, raw) {
  const secret = process.env.SELLAUTH_WEBHOOK_SECRET;
  if (!secret) throw new Error('SELLAUTH_WEBHOOK_SECRET is not configured');
  const provided = String(req.headers['x-signature'] || '').trim().replace(/^sha256=/i, '');
  if (!provided) throw new Error('Missing X-Signature');
  const expected = crypto.createHmac('sha256', secret).update(raw, 'utf8').digest('hex');
  if (provided.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(provided), Buffer.from(expected))) {
    throw new Error('Invalid SellAuth webhook signature');
  }
}

function getProductKey(body) {
  const item = body?.item || {};
  const productId = String(item.product_id ?? body?.product_id ?? '');
  const variantId = String(item.variant_id ?? body?.variant_id ?? '');
  // Prefer an exact variant match; fall back to product ID.
  return VARIANT_IDS[variantId] || PRODUCT_IDS[productId] || null;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).send('Method not allowed.');
  try {
    const raw = await rawBody(req);
    verifySignature(req, raw);
    const body = JSON.parse(raw || '{}');

    if (String(body.event || '') !== 'INVOICE.ITEM.DELIVER-DYNAMIC') {
      return res.status(200).send('');
    }
    if (String(body.status || '').toLowerCase() !== 'completed') {
      return res.status(200).send('');
    }

    const key = getProductKey(body);
    const product = PRODUCTS[key];
    if (!product) return res.status(400).send('Unknown product.');

    const email = safeEmail(body.email || body.customer?.email || '');
    if (!email) return res.status(400).send('A valid customer email is required.');

    const fulfillmentKey = `sellauth:${body.unique_id || body.id || `${body.invoice_id || 'invoice'}:${body.item?.variant_id || body.item?.product_id || key}`}`;
    const existing = await getDynamicDelivery(fulfillmentKey);
    if (existing?.download_url) return res.status(200).send(existing.download_url);

    const base = (process.env.APP_BASE_URL || 'https://cryptomarketintelligence.pro').replace(/\/$/, '');
    const token = signPayload({
      product: key,
      email,
      payment_id: String(body.id || body.unique_id || body.invoice_id || fulfillmentKey),
      payment_verified: true,
      provider: 'sellauth',
      iat: Date.now(),
      exp: Date.now() + 30 * 24 * 60 * 60 * 1000
    });
    const downloadUrl = `${base}/api/download?token=${encodeURIComponent(token)}`;
    const dashboardUrl = `${base}/dashboard.html?token=${encodeURIComponent(token)}`;

    await saveDynamicDelivery({
      fulfillment_key: fulfillmentKey,
      product: key,
      product_id: String(body.item?.product_id || body.product_id || ''),
      email,
      token,
      download_url: downloadUrl,
      dashboard_url: dashboardUrl
    });
    await recordOrder({
      provider: 'sellauth',
      payment_id: String(body.id || body.unique_id || body.invoice_id || fulfillmentKey),
      order_id: String(body.invoice_id || body.unique_id || body.id || ''),
      product: key,
      leads: product.leads,
      amount: body.price || body.price_eur || null,
      currency: body.currency || 'EUR',
      email,
      payment_status: 'PAID',
      delivery_status: 'ready'
    });

    // SellAuth Dynamic Delivery expects plain text. One URL is enough for the purchased item.
    return res.status(200).send(downloadUrl);
  } catch (error) {
    return res.status(400).send(error instanceof Error ? error.message : 'Dynamic delivery failed.');
  }
}
