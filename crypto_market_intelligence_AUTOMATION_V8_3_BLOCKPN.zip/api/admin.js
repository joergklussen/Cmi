import crypto from 'node:crypto';
import { adminStats, dbConfigured } from './_db.js';
import { PRODUCTS, shoppexDynamicSecret, normalizeTitle } from './_lib.js';

function json(res,status,body){res.status(status).setHeader('Content-Type','application/json; charset=utf-8');res.setHeader('Cache-Control','no-store');res.setHeader('X-Robots-Tag','noindex, nofollow');return res.json(body)}
function token(){return crypto.randomBytes(32).toString('base64url')}
function sign(v){return crypto.createHmac('sha256',process.env.ADMIN_KEY).update(v).digest('base64url')}
function session(){const exp=Date.now()+8*60*60*1000; const body=`${exp}.${token()}`; return `${body}.${sign(body)}`}
function verify(t){const [exp,nonce,sig]=String(t||'').split('.'); if(!exp||!nonce||!sig||Date.now()>Number(exp)) throw new Error('Invalid or expired admin session'); const body=`${exp}.${nonce}`; const expected=sign(body); if(sig.length!==expected.length||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected))) throw new Error('Invalid admin session'); return true}

async function shoppexRequest(path, options={}){
  const key=process.env.SHOPPEX_API_KEY;
  if(!key) throw new Error('SHOPPEX_API_KEY is not configured');
  const r=await fetch(`https://api.shoppex.io/dev/v1${path}`,{
    ...options,
    headers:{Authorization:`Bearer ${key}`,Accept:'application/json','Content-Type':'application/json',...(options.headers||{})}
  });
  const data=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(`Shoppex API ${r.status}: ${data?.error?.message||data?.message||'request failed'}`);
  return data.data ?? data;
}

const CMI_PRODUCTS=[
  {key:'test',title:'Crypto Lead Test Pack – 100 Leads',price:10},
  {key:'starter',title:'Crypto Lead Starter Pack – 1,000 Leads',price:49},
  {key:'advanced',title:'Crypto Lead Advanced Pack – 10,000 Leads',price:199},
  {key:'pro',title:'Crypto Lead Pro Pack – 25,000 Leads',price:299},
  {key:'business',title:'Crypto Lead Business Database – 115,000 Leads',price:999}
];

async function listShoppexProducts(){
  const data=await shoppexRequest('/products?limit=100');
  return Array.isArray(data) ? data : (data?.items || data?.products || []);
}

async function syncShoppex(){
  const webhook=(process.env.APP_BASE_URL||'https://cryptomarketintelligence.pro').replace(/\/$/,'')+'/api/shoppex-dynamic';
  const products=await listShoppexProducts();
  const results=[];
  for(const spec of CMI_PRODUCTS){
    const wanted=normalizeTitle(spec.title);
    let p=products.find(x=>{
      const t=normalizeTitle(x.title);
      return t===wanted || t===wanted.replace(/ - \d[\d,.]* leads$/,'') || (t.includes('crypto lead') && t.includes(spec.key));
    });
    const payload={
      title:spec.title,price:spec.price,currency:'EUR',type:'DYNAMIC',
      dynamic_webhook:webhook,dynamic_webhook_secret:shoppexDynamicSecret(p?.id||p?.uniqid||spec.key),
      metadata:{cmi_product_key:spec.key,cmi_leads:String(PRODUCTS[spec.key].leads)},
      quantity_min:1,quantity_max:1,description:
        `${PRODUCTS[spec.key].leads.toLocaleString('en-US')} crypto leads for targeted sales, marketing, customer acquisition and data-driven outreach.`,
      delivery_text:`Instant digital delivery — ${PRODUCTS[spec.key].leads.toLocaleString('en-US')} crypto leads.`,
      sort_priority:CMI_PRODUCTS.findIndex(x=>x.key===spec.key)
    };
    if(p){
      const id=p.id||p.uniqid;
      payload.dynamic_webhook_secret=shoppexDynamicSecret(id);
      const updated=await shoppexRequest(`/products/${encodeURIComponent(id)}`,{method:'PATCH',body:JSON.stringify(payload)});
      results.push({key:spec.key,action:'updated',id,secret_mode:'derived_from_ORDER_SECRET',title:updated?.title||p.title});
    }else{
      // For creation the secret must be derived from the returned product ID, so create first.
      const createPayload={...payload};
      delete createPayload.dynamic_webhook_secret;
      const created=await shoppexRequest('/products',{method:'POST',body:JSON.stringify(createPayload)});
      const createdId=created?.id||created?.uniqid;
      if(!createdId) throw new Error(`Shoppex did not return an id for ${spec.key}`);
      const updated=await shoppexRequest(`/products/${encodeURIComponent(createdId)}`,{
        method:'PATCH',
        body:JSON.stringify({dynamic_webhook_secret:shoppexDynamicSecret(createdId)})
      });
      results.push({key:spec.key,action:'created',id:createdId,secret_mode:'derived_from_ORDER_SECRET',title:updated?.title||created?.title});
    }
  }
  return {webhook,products:results};
}

export default async function handler(req,res){
  if(req.method!=='POST') return json(res,405,{ok:false,error:'method_not_allowed'});
  try{
    if(!process.env.ADMIN_KEY) return json(res,503,{ok:false,error:'ADMIN_KEY_not_configured'});
    const body=typeof req.body==='string'?JSON.parse(req.body||'{}'):(req.body||{});
    if(body.action==='login'){
      if(String(body.key||'')!==process.env.ADMIN_KEY) return json(res,401,{ok:false,error:'invalid_admin_key'});
      return json(res,200,{ok:true,session:session(),expires_in:28800});
    }
    verify(body.session);
    if(body.action==='stats') return json(res,200,{ok:true,db_configured:dbConfigured(),...(await adminStats())});
    if(body.action==='shoppex_sync') return json(res,200,{ok:true,shoppex:await syncShoppex()});
    return json(res,400,{ok:false,error:'unknown_action'});
  }catch(error){return json(res,400,{ok:false,error:String(error?.message||error)})}
}
