import crypto from 'node:crypto';
import { PRODUCTS, safeEmail, signPayload, normalizeTitle, shoppexDynamicSecret } from './_lib.js';
import { getDynamicDelivery, saveDynamicDelivery, recordOrder } from './_db.js';

const TITLE_MAP = {
  'crypto lead test pack': 'test',
  'crypto lead test pack - 100 leads': 'test',
  'crypto lead starter pack': 'starter',
  'crypto lead starter pack - 1,000 leads': 'starter',
  'crypto lead advanced pack': 'advanced',
  'crypto lead advanced pack - 10,000 leads': 'advanced',
  'crypto lead pro pack': 'pro',
  'crypto lead pro pack - 25,000 leads': 'pro',
  'crypto lead business database': 'business',
  'crypto lead business database - 115,000 leads': 'business'
};

function rawBody(req) {
  if (typeof req.body === 'string') return req.body;
  return JSON.stringify(req.body || {});
}

function header(req, name) {
  const v = req.headers[name.toLowerCase()];
  return Array.isArray(v) ? v[0] : v;
}

function verifyV2(req, raw, productId) {
  const signature = header(req, 'x-shoppex-signature-v2');
  const deliveryId = header(req, 'x-shoppex-delivery-id');
  const timestamp = header(req, 'x-shoppex-timestamp');
  if (!signature || !deliveryId || !timestamp) throw new Error('Missing Shoppex V2 signature headers');

  const segments = String(signature).split(',').map(s => s.trim());
  const parts = Object.fromEntries(segments.filter(s => s.includes('=')).map(s => {
    const i = s.indexOf('=');
    return [s.slice(0, i), s.slice(i + 1)];
  }));
  if (!segments.includes('v1') || parts.t !== String(timestamp)) throw new Error('Invalid Shoppex V2 signature format');

  const ts = Number(timestamp);
  if (!Number.isFinite(ts) || Math.abs(Math.floor(Date.now()/1000) - ts) > 300) throw new Error('Expired Shoppex V2 signature');
  if (!/^[0-9a-f]{64}$/i.test(parts.h || '')) throw new Error('Invalid Shoppex V2 digest');

  const expected = crypto.createHmac('sha256', shoppexDynamicSecret(productId))
    .update(`${deliveryId}.${timestamp}.${raw}`)
    .digest('hex');

  if (!crypto.timingSafeEqual(Buffer.from(parts.h, 'hex'), Buffer.from(expected, 'hex'))) {
    throw new Error('Invalid Shoppex V2 signature');
  }
  return { deliveryId, timestamp };
}

function productKey(body) {
  const candidates = [
    body.product?.metadata?.cmi_product_key,
    body.line_item?.metadata?.cmi_product_key,
    body.productKey,
    body.product_key,
    body.productTitle,
    body.product_title,
    body.product?.title,
    body.line_item?.product_title,
    body.variantTitle,
    body.variant_title
  ];
  for (const c of candidates) {
    const n = normalizeTitle(c);
    if (TITLE_MAP[n]) return TITLE_MAP[n];
    if (n === 'test') return 'test';
    if (n === 'starter') return 'starter';
    if (n === 'advanced') return 'advanced';
    if (n === 'pro') return 'pro';
    if (n === 'business') return 'business';
    const m = n.match(/(?:^|[^0-9])115[,.]?000(?:[^0-9]|$)/); if (m) return 'business';
    if (/25[,.]?000/.test(n)) return 'pro';
    if (/10[,.]?000/.test(n)) return 'advanced';
    if (/1[,.]?000/.test(n)) return 'starter';
    if (/\b100\b/.test(n)) return 'test';
  }
  return null;
}

function json(res, status, body) {
  res.status(status).setHeader('Content-Type','application/json; charset=utf-8');
  res.setHeader('Cache-Control','no-store');
  return res.json(body);
}

export default async function handler(req,res) {
  if (req.method !== 'POST') return json(res,405,{error:'method_not_allowed'});
  try {
    const raw = rawBody(req);
    const body = typeof req.body === 'object' ? req.body : JSON.parse(raw || '{}');
    const productId = String(body.productId || body.product_id || body.product?.id || body.product?.uniqid || body.line_item?.product_id || '').trim();
    if (!productId) return json(res,400,{error:'missing_product_id'});

    const { deliveryId } = verifyV2(req, raw, productId);
    const fulfillmentKey = String(header(req,'x-shoppex-idempotency-key') || body.idempotencyKey || body.idempotency_key || deliveryId || '').trim();
    if (!fulfillmentKey) return json(res,400,{error:'missing_idempotency_key'});

    const existing = await getDynamicDelivery(fulfillmentKey);
    if (existing) {
      return json(res,200,{data:{
        service_text:`Your ${PRODUCTS[existing.product].leads.toLocaleString('en-US')} crypto leads are ready.`,
        dynamic_response:{download_url:existing.download_url,dashboard_url:existing.dashboard_url,token:existing.token},
        deliveryType:'DYNAMIC', count:1
      }});
    }

    const key = productKey(body);
    const product = PRODUCTS[key];
    if (!product) return json(res,400,{error:'unknown_product'});

    const email = safeEmail(
      body.customerEmail || body.customer_email ||
      body.invoice?.customer_email || body.invoice?.customerEmail || ''
    );
    const orderId = String(body.invoiceId || body.invoice_id || body.invoice?.uniqid || body.invoice?.id || fulfillmentKey);
    const base = (process.env.APP_BASE_URL || 'https://cryptomarketintelligence.pro').replace(/\/$/,'');
    const token = signPayload({
      product:key,email,payment_id:orderId,payment_verified:true,provider:'shoppex-dynamic',
      iat:Date.now(),exp:Date.now()+30*24*60*60*1000
    });
    const downloadUrl=`${base}/api/download?token=${encodeURIComponent(token)}`;
    const dashboardUrl=`${base}/dashboard.html?token=${encodeURIComponent(token)}`;

    const saved = await saveDynamicDelivery({
      fulfillment_key:fulfillmentKey,product:key,product_id:productId,email,token,download_url:downloadUrl,dashboard_url:dashboardUrl
    });
    const final = saved.row || {product:key,token,download_url:downloadUrl,dashboard_url:dashboardUrl};

    await recordOrder({
      provider:'shoppex-dynamic',payment_id:orderId,order_id:orderId,product:key,leads:product.leads,
      amount:body.invoice?.total || body.line_item?.total || product.amount,
      currency:body.invoice?.currency || 'EUR',email,payment_status:'PAID',delivery_status:'delivered'
    });

    return json(res,200,{data:{
      service_text:`Your ${product.leads.toLocaleString('en-US')} crypto leads are ready.`,
      dynamic_response:{download_url:final.download_url,dashboard_url:final.dashboard_url,token:final.token},
      deliveryType:'DYNAMIC',count:1
    }});
  } catch(error) {
    console.error('CMI Shoppex dynamic delivery',error);
    return json(res,401,{error:error instanceof Error ? error.message : String(error)});
  }
}
