import { PRODUCTS, normalizeProduct, safeEmail, signPayload } from './_lib.js';

function json(res, status, body) {
  res.status(status).setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Robots-Tag', 'noindex, nofollow');
  return res.json(body);
}

export default async function handler(req, res) {
  if (req.method !== 'GET') return json(res, 405, { error: 'method_not_allowed' });
  try {
    const url = new URL(req.url, `https://${req.headers.host || 'cryptomarketintelligence.pro'}`);
    const key = normalizeProduct(url.searchParams.get('product'));
    if (!key) return json(res, 400, { error: 'invalid_product' });
    const product = PRODUCTS[key];
    const email = safeEmail(url.searchParams.get('email'));
    if (!email) return json(res, 400, { error: 'email_required', message: 'A valid email address is required before checkout.' });

    const base = (process.env.APP_BASE_URL || 'https://cryptomarketintelligence.pro').replace(/\/$/, '');
    const providerParam = url.searchParams.get('provider');
    if (!providerParam) return json(res, 400, { error: 'payment_method_required', message: 'Choose Mollie, PayLio, Direct Crypto or Blockpn before checkout.' });
    const provider = providerParam.toLowerCase();

    if (provider === 'blockpn') {
      const apiKey = process.env.BLOCKPN_API_KEY;
      if (!apiKey || !process.env.ORDER_SECRET) return json(res, 503, { error: 'blockpn_checkout_not_configured', missing: [!apiKey&&'BLOCKPN_API_KEY',!process.env.ORDER_SECRET&&'ORDER_SECRET'].filter(Boolean) });
      const order = signPayload({ product: key, email, iat: Date.now() });
      const payload = {
        amount: product.amount,
        currency: 'EUR',
        accept: 'all',
        customer_email: email,
        reference: order,
        return_url: `${base}/api/blockpn-return?order=${encodeURIComponent(order)}`,
        webhook_url: `${base}/api/blockpn-webhook`,
        metadata: { product: key, email, order }
      };
      const upstream = await fetch('https://api.blockpn.com/v1/payments', {
        method: 'POST',
        headers: { Authorization: `Bearer ${apiKey}`, 'X-Payment-Mode': process.env.BLOCKPN_PAYMENT_MODE || 'live', 'Content-Type': 'application/json', Accept: 'application/json', 'X-Idempotency-Key': `cmi-${key}-${Date.now()}-${Math.random().toString(36).slice(2)}` },
        body: JSON.stringify(payload)
      });
      const text = await upstream.text(); let data = {}; try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text.slice(0, 1000) }; }
      const checkout = data.checkout_url || data.data?.checkout_url;
      const paymentId = data.id || data.data?.id;
      if (!upstream.ok || !checkout || !paymentId) return json(res, upstream.status >= 400 && upstream.status < 600 ? upstream.status : 502, { error: 'blockpn_checkout_failed', blockpn_status: upstream.status, details: data });
      res.statusCode = 303; res.setHeader('Location', checkout); res.setHeader('Cache-Control', 'no-store'); return res.end();
    }

    if (provider === 'paylio') {
      const apiKey = process.env.PAYLIO_API_KEY;
      const wallet = process.env.PAYLIO_WALLET_ADDRESS;
      if (!apiKey || !wallet || !process.env.ORDER_SECRET) return json(res, 503, { error: 'checkout_not_configured', missing: [!apiKey&&'PAYLIO_API_KEY',!wallet&&'PAYLIO_WALLET_ADDRESS',!process.env.ORDER_SECRET&&'ORDER_SECRET'].filter(Boolean) });
      const order = signPayload({ product: key, email, iat: Date.now() });
      const payload = { address: wallet, callback: `${base}/api/paylio-callback?order=${encodeURIComponent(order)}`, amount: product.amount, currency: 'EUR', passFeeToCustomer: true, email, note: `CMI ${key} — ${product.name}` };
      const upstream = await fetch('https://paylio.org/api/v1/wallet', { method: 'POST', headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(payload) });
      const text = await upstream.text(); let data = {}; try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text.slice(0, 1000) }; }
      if (!upstream.ok || !data.checkout_url) return json(res, upstream.status >= 400 && upstream.status < 600 ? upstream.status : 502, { error: 'paylio_checkout_failed', paylio_status: upstream.status, details: data });
      res.statusCode = 302; res.setHeader('Location', data.checkout_url); res.setHeader('Cache-Control', 'no-store'); return res.end();
    }

    if (provider === 'btcpay' || provider === 'crypto') {
      const instance = (process.env.BTCPAY_INSTANCE || '').replace(/\/$/, '');
      const storeId = process.env.BTCPAY_STORE_ID;
      const apiKey = process.env.BTCPAY_API_KEY;
      if (!instance || !storeId || !apiKey || !process.env.ORDER_SECRET) {
        return json(res, 503, { error: 'btcpay_checkout_not_configured', missing: [!instance&&'BTCPAY_INSTANCE',!storeId&&'BTCPAY_STORE_ID',!apiKey&&'BTCPAY_API_KEY',!process.env.ORDER_SECRET&&'ORDER_SECRET'].filter(Boolean) });
      }
      const order = signPayload({ product: key, email, iat: Date.now() });
      const payload = {
        amount: product.amount,
        currency: 'EUR',
        metadata: { orderId: order, itemDesc: `CMI ${key} — ${product.name}` },
        checkout: {
          redirectURL: `${base}/api/btcpay-return?order=${encodeURIComponent(order)}`,
          defaultLanguage: 'en'
        }
      };
      const upstream = await fetch(`${instance}/api/v1/stores/${encodeURIComponent(storeId)}/invoices`, {
        method: 'POST', headers: { Authorization: `token ${apiKey}`, 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(payload)
      });
      const text = await upstream.text(); let data = {}; try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text.slice(0, 1000) }; }
      if (!upstream.ok || !data.id || !data.checkoutLink) return json(res, upstream.status >= 400 && upstream.status < 600 ? upstream.status : 502, { error: 'btcpay_checkout_failed', btcpay_status: upstream.status, details: data });
      res.statusCode = 303; res.setHeader('Location', data.checkoutLink); res.setHeader('Cache-Control', 'no-store'); return res.end();
    }

    const apiKey = process.env.MOLLIE_API_KEY;
    if (!apiKey || !process.env.ORDER_SECRET) return json(res, 503, { error: 'mollie_checkout_not_configured', missing: [!apiKey&&'MOLLIE_API_KEY',!process.env.ORDER_SECRET&&'ORDER_SECRET'].filter(Boolean) });

    const order = signPayload({ product: key, email, iat: Date.now() });
    const payload = {
      amount: { currency: 'EUR', value: product.amount },
      description: `CMI ${key} — ${product.name}`.slice(0, 255),
      redirectUrl: `${base}/api/mollie-return?order=${encodeURIComponent(order)}`,
      cancelUrl: `${base}/checkout?product=${encodeURIComponent(key)}&canceled=1`,
      webhookUrl: `${base}/api/mollie-webhook`,
      locale: 'de_DE',
      metadata: { product: key, email, order }
    };
    const upstream = await fetch('https://api.mollie.com/v2/payments', { method: 'POST', headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(payload) });
    const text = await upstream.text(); let data = {}; try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text.slice(0, 1000) }; }
    const checkout = data?._links?.checkout?.href;
    if (!upstream.ok || !checkout || !data.id) return json(res, upstream.status >= 400 && upstream.status < 600 ? upstream.status : 502, { error: 'mollie_checkout_failed', mollie_status: upstream.status, details: data });

    // Mollie does not append the payment ID to redirectUrl automatically.
    // Add the actual payment ID after creation so the return endpoint can
    // retrieve and verify the exact payment. This is the pattern Mollie
    // documents for redirect URLs containing a unique identifier.
    const returnUrl = `${base}/api/mollie-return?id=${encodeURIComponent(data.id)}&order=${encodeURIComponent(order)}`;
    const update = await fetch(`https://api.mollie.com/v2/payments/${encodeURIComponent(data.id)}`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ redirectUrl: returnUrl })
    });
    if (!update.ok) {
      const updateText = await update.text();
      let updateData = {};
      try { updateData = updateText ? JSON.parse(updateText) : {}; } catch { updateData = { raw: updateText.slice(0, 1000) }; }
      return json(res, update.status >= 400 && update.status < 600 ? update.status : 502, { error: 'mollie_redirect_setup_failed', mollie_status: update.status, payment_id: data.id, details: updateData });
    }

    res.statusCode = 303; res.setHeader('Location', checkout); res.setHeader('Cache-Control', 'no-store'); return res.end();
  } catch (error) {
    return json(res, 500, { error: 'function_error', message: error instanceof Error ? error.message : String(error) });
  }
}
