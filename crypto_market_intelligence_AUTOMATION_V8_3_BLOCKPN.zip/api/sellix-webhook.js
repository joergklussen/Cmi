import crypto from 'node:crypto';
import { PRODUCTS, safeEmail, signPayload } from './_lib.js';

export const config = { api: { bodyParser: false } };

const ALIASES = {
  'test': 'test',
  'crypto lead test pack': 'test',
  'crypto lead test pack – 100 leads': 'test',
  'crypto lead test pack - 100 leads': 'test',
  'starter': 'starter',
  'crypto lead starter pack': 'starter',
  'crypto lead starter pack – 1,000 leads': 'starter',
  'crypto lead starter pack - 1,000 leads': 'starter',
  'advanced': 'advanced',
  'crypto lead advanced pack': 'advanced',
  'crypto lead advanced pack – 10,000 leads': 'advanced',
  'crypto lead advanced pack - 10,000 leads': 'advanced',
  'pro': 'pro',
  'crypto lead pro pack': 'pro',
  'crypto lead pro pack – 25,000 leads': 'pro',
  'crypto lead pro pack - 25,000 leads': 'pro',
  'business': 'business',
  'crypto lead business database': 'business',
  'crypto lead business database – 115,000 leads': 'business',
  'crypto lead business database - 115,000 leads': 'business'
};

function normalize(value) {
  const s = String(value || '').trim().toLowerCase().replace(/[–—]/g, '-').replace(/\s+/g, ' ');
  if (ALIASES[s]) return ALIASES[s];
  if (/115[,.]?000/.test(s)) return 'business';
  if (/25[,.]?000/.test(s)) return 'pro';
  if (/10[,.]?000/.test(s)) return 'advanced';
  if (/1[,.]?000/.test(s)) return 'starter';
  if (/\b100\b/.test(s)) return 'test';
  return null;
}

function readRaw(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c)));
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function verifySignature(req, raw) {
  const secret = process.env.SELLIX_WEBHOOK_SECRET;
  if (!secret) throw new Error('SELLIX_WEBHOOK_SECRET is not configured');
  const provided = String(req.headers['x-sellix-signature'] || '').trim().replace(/^sha256=/i, '');
  if (!provided) throw new Error('Missing X-Sellix-Signature');
  const expected = crypto.createHmac('sha256', secret).update(raw, 'utf8').digest('hex');
  if (provided.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(provided), Buffer.from(expected))) {
    throw new Error('Invalid Sellix webhook signature');
  }
}

async function sellixGet(path) {
  const key = process.env.SELLIX_API_KEY;
  if (!key) throw new Error('SELLIX_API_KEY is not configured');
  const r = await fetch(`https://api.sellix.gg/v1${path}`, {
    headers: { Authorization: `Bearer ${key}`, Accept: 'application/json' }
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`Sellix API lookup failed (${r.status})`);
  return data.data ?? data;
}

function orderId(body) {
  return body?.data?.order?.uuid || body?.data?.order?.id || body?.order?.uuid || body?.order?.id || '';
}

function productKey(order) {
  const item = Array.isArray(order?.items) ? order.items[0] : null;
  const candidates = [item?.product_name, item?.name, item?.product_id, order?.product_name, order?.product_id, order?.title];
  for (const c of candidates) { const k = normalize(c); if (k) return k; }
  return null;
}

async function sendEmail(email, product, id, downloadUrl, dashboardUrl) {
  const key = process.env.RESEND_API_KEY;
  const from = process.env.FROM_EMAIL;
  if (!key || !from || !email) return false;
  const r = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      from, to: [email],
      subject: `Your Crypto Market Intelligence ${product.name} access`,
      html: `<h2>Payment confirmed</h2><p>Your <strong>${product.name}</strong> purchase is confirmed.</p><p><a href="${downloadUrl}">Download your ${product.leads.toLocaleString('en-US')} leads</a></p><p><a href="${dashboardUrl}">Open your CMI dashboard</a></p><p>Sellix order: ${id}</p>`
    })
  });
  return r.ok;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ ok: false, error: 'method_not_allowed' });
  try {
    const raw = await readRaw(req);
    verifySignature(req, raw);
    const body = JSON.parse(raw || '{}');
    const event = String(req.headers['x-sellix-event'] || body.event || '').toLowerCase();
    if (event && event !== 'order.paid') return res.status(200).json({ ok: true, ignored: event });

    const id = orderId(body);
    if (!id) return res.status(400).json({ ok: false, error: 'missing_order_id' });
    const order = await sellixGet(`/orders/${encodeURIComponent(id)}`);
    const status = String(order?.status || '').toLowerCase();
    if (status !== 'paid' && status !== 'completed' && status !== 'delivering') return res.status(200).json({ ok: true, pending: status || 'unknown' });

    const key = productKey(order);
    const product = PRODUCTS[key];
    if (!product) return res.status(400).json({ ok: false, error: 'unknown_product' });
    const email = safeEmail(order.customer_email || order.email || body.data?.order?.customer_email || '');
    const base = (process.env.APP_BASE_URL || 'https://cryptomarketintelligence.pro').replace(/\/$/, '');
    const access = signPayload({ product: key, email, payment_id: id, payment_verified: true, provider: 'sellix', iat: Date.now(), exp: Date.now() + 30*24*60*60*1000 });
    const downloadUrl = `${base}/api/download?token=${encodeURIComponent(access)}`;
    const dashboardUrl = `${base}/dashboard.html?token=${encodeURIComponent(access)}`;
    let emailed = false;
    try { emailed = await sendEmail(email, product, id, downloadUrl, dashboardUrl); } catch {}
    return res.status(200).json({ ok: true, order_id: id, product: key, leads: product.leads, download_url: downloadUrl, dashboard_url: dashboardUrl, emailed });
  } catch (e) {
    return res.status(400).json({ ok: false, error: e instanceof Error ? e.message : String(e) });
  }
}
