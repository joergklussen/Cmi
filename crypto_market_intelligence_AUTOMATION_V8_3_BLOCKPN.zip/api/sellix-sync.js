import crypto from 'node:crypto';
import { PRODUCTS } from './_lib.js';

const PRODUCT_DEFS = {
  test: { name: 'Crypto Lead Test Pack – 100 Leads', description: '100 crypto-related leads for testing and initial outreach. Includes available contact and profile data fields.', priority: 10 },
  starter: { name: 'Crypto Lead Starter Pack – 1,000 Leads', description: '1,000 crypto leads for targeted customer acquisition, outreach and marketing campaigns.', priority: 20 },
  advanced: { name: 'Crypto Lead Advanced Pack – 10,000 Leads', description: '10,000 crypto leads for larger campaigns, segmentation and scalable outreach.', priority: 30 },
  pro: { name: 'Crypto Lead Pro Pack – 25,000 Leads', description: '25,000 crypto leads for professional sales and marketing teams.', priority: 40 },
  business: { name: 'Crypto Lead Business Database – 115,000 Leads', description: '115,000 crypto leads for professional businesses and large-scale acquisition projects.', priority: 50 }
};

function adminOk(req) {
  const expected = process.env.ADMIN_KEY || process.env.SELLIX_SYNC_KEY;
  if (!expected) return false;
  const got = String(req.headers['x-admin-key'] || req.headers['x-sellix-sync-key'] || '');
  return got && crypto.timingSafeEqual(Buffer.from(got), Buffer.from(expected));
}

async function api(method, path, body, key) {
  const headers = { Authorization: `Bearer ${key}`, Accept: 'application/json', 'Content-Type': 'application/json' };
  if (method !== 'GET') headers['Idempotency-Key'] = `cmi-${method.toLowerCase()}-${path.replace(/[^a-z0-9]+/gi,'-')}`;
  const r = await fetch(`https://api.sellix.gg/v1${path}`, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`Sellix ${method} ${path} failed (${r.status}): ${data?.type || data?.error || 'unknown_error'}`);
  return data;
}

async function listProducts(key) {
  const data = await api('GET', '/products?limit=100', null, key);
  return data.data || [];
}

async function ensureWebhook(key) {
  const existing = await api('GET', '/webhooks', null, key);
  const hooks = existing.data || [];
  const url = `${(process.env.APP_BASE_URL || 'https://cryptomarketintelligence.pro').replace(/\/$/,'')}/api/sellix-webhook`;
  const found = hooks.find(h => h.url === url && (h.events || []).includes('order.paid') && h.status !== 'disabled');
  if (found) return { action: 'existing', id: found.id, signing_secret_required: !process.env.SELLIX_WEBHOOK_SECRET };
  const created = await api('POST', '/webhooks', { url, events: ['order.paid', 'order.refunded'], description: 'CMI automatic paid-order fulfillment' }, key);
  return { action: 'created', id: created?.id || created?.data?.id, signing_secret: created?.signing_secret || created?.data?.signing_secret };
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ ok:false, error:'method_not_allowed' });
  if (!adminOk(req)) return res.status(401).json({ ok:false, error:'unauthorized' });
  const key = process.env.SELLIX_API_KEY;
  if (!key) return res.status(503).json({ ok:false, error:'SELLIX_API_KEY is not configured' });
  try {
    const products = await listProducts(key);
    const result = [];
    for (const [keyName, product] of Object.entries(PRODUCTS)) {
      const def = PRODUCT_DEFS[keyName];
      const target = products.find(p => String(p.name || '').trim().toLowerCase() === def.name.toLowerCase()) || products.find(p => String(p.name || '').toLowerCase().includes(`${product.leads.toLocaleString('en-US')} leads`.toLowerCase()));
      const payload = { name: def.name, type: 'service', price_cents: Math.round(Number(product.amount) * 100), currency: 'EUR', description: def.description, status: 'active' };
      if (target?.id) {
        const updated = await api('PATCH', `/products/${encodeURIComponent(target.id)}`, payload, key);
        result.push({ product:keyName, action:'updated', id:target.id, name:updated?.data?.name || updated?.name || def.name });
      } else {
        const created = await api('POST', '/products', payload, key);
        const id = created?.data?.id || created?.id;
        result.push({ product:keyName, action:'created', id, name:created?.data?.name || created?.name || def.name });
      }
    }
    const webhook = await ensureWebhook(key);
    return res.status(200).json({ ok:true, products:result, webhook, note: webhook.signing_secret ? 'Save this signing secret once in Vercel as SELLIX_WEBHOOK_SECRET.' : 'Webhook already exists; keep SELLIX_WEBHOOK_SECRET set in Vercel.' });
  } catch (e) {
    return res.status(500).json({ ok:false, error:e instanceof Error ? e.message : String(e) });
  }
}
