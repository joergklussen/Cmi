function json(res, status, body) {
  res.status(status).setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Robots-Tag', 'noindex, nofollow');
  return res.json(body);
}

export default async function handler(req, res) {
  if (req.method !== 'GET') return json(res, 405, { ok: false, error: 'method_not_allowed' });

  const checks = {
    app_base_url: Boolean(process.env.APP_BASE_URL),
    order_secret: Boolean(process.env.ORDER_SECRET),
    mollie_api_key: Boolean(process.env.MOLLIE_API_KEY),
    paylio_api_key: Boolean(process.env.PAYLIO_API_KEY),
    paylio_wallet: Boolean(process.env.PAYLIO_WALLET_ADDRESS),
    resend_api_key: Boolean(process.env.RESEND_API_KEY),
    from_email: Boolean(process.env.FROM_EMAIL),
    database_url: Boolean(process.env.DATABASE_URL || process.env.POSTGRES_URL),
    admin_key: Boolean(process.env.ADMIN_KEY)
  };

  // Do not return secret values. This endpoint only reports configuration presence.
  const required = ['order_secret', 'mollie_api_key'];
  const ready = required.every((key) => checks[key]);

  return json(res, ready ? 200 : 503, {
    ok: ready,
    service: 'crypto-market-intelligence',
    payment_primary: 'mollie',
    payment_alternatives: ['paylio', 'direct-crypto'],
    checks,
    timestamp: new Date().toISOString()
  });
}
