import crypto from 'node:crypto';
import { PRODUCTS, safeEmail, signPayload } from './_lib.js';
import { recordOrder, updateOrder } from './_db.js';

const PRODUCT_ALIASES = {
  'test': 'test',
  'crypto lead test pack': 'test',
  'crypto lead test pack – 100 leads': 'test',
  'crypto lead test pack - 100 leads': 'test',
  'starter': 'starter',
  'crypto lead starter pack': 'starter',
  'crypto lead starter pack – 1,000 leads': 'starter',
  'crypto lead starter pack - 1,000 leads': 'starter',
  'advanced': 'advanced',
  'crypto lead advanced pack': 'advanced',
  'crypto lead advanced pack – 10,000 leads': 'advanced',
  'crypto lead advanced pack - 10,000 leads': 'advanced',
  'pro': 'pro',
  'crypto lead pro pack': 'pro',
  'crypto lead pro pack – 25,000 leads': 'pro',
  'crypto lead pro pack - 25,000 leads': 'pro',
  'business': 'business',
  'crypto lead business database': 'business',
  'crypto lead business database – 115,000 leads': 'business',
  'crypto lead business database - 115,000 leads': 'business'
};

function normalize(value) {
  const s = String(value || '').trim().toLowerCase();
  if (PRODUCT_ALIASES[s]) return PRODUCT_ALIASES[s];
  if (/115[,.]?000/.test(s)) return 'business';
  if (/25[,.]?000/.test(s)) return 'pro';
  if (/10[,.]?000/.test(s)) return 'advanced';
  if (/1[,.]?000/.test(s)) return 'starter';
  if (/\b100\b/.test(s)) return 'test';
  return null;
}

function getRawBody(req) {
  if (typeof req.body === 'string') return req.body;
  return JSON.stringify(req.body || {});
}

function verifyWebhook(req, raw) {
  const secret = process.env.SHOPPEX_WEBHOOK_SECRET;
  if (!secret) throw new Error('SHOPPEX_WEBHOOK_SECRET is not configured');
  const signature = req.headers['x-shoppex-signature'] || req.headers['shoppex-signature'] || req.headers['x-webhook-signature'];
  if (!signature) throw new Error('Missing Shoppex webhook signature');
  const expected = crypto.createHmac('sha256', secret).update(raw).digest('hex');
  const provided = String(signature).replace(/^sha256=/i, '').trim();
  if (provided.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(provided), Buffer.from(expected))) {
    throw new Error('Invalid Shoppex webhook signature');
  }
}

async function getOrder(orderId) {
  const key = process.env.SHOPPEX_API_KEY;
  if (!key) throw new Error('SHOPPEX_API_KEY is not configured');
  const r = await fetch(`https://api.shoppex.io/dev/v1/orders/${encodeURIComponent(orderId)}`, {
    headers: { Authorization: `Bearer ${key}`, Accept: 'application/json' }
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`Shoppex order lookup failed (${r.status})`);
  return data.data || data;
}

function findOrderId(body) {
  return body.order_id || body.orderId || body.order?.id || body.order?.uniqid || body.data?.order_id || body.data?.order?.id || body.data?.order?.uniqid || body.uniqid || body.id || '';
}

function findProduct(order) {
  const item = Array.isArray(order.items) ? order.items[0] : null;
  const candidates = [
    item?.product_id,
    item?.product_title,
    item?.variant_title,
    order.product_id,
    order.product_title,
    order.title,
    order.custom_fields?.product,
    order.custom_fields?.product_key
  ];
  for (const candidate of candidates) {
    const key = normalize(candidate);
    if (key) return key;
  }
  return null;
}

async function sendEmail(email, product, orderId, downloadUrl, dashboardUrl) {
  const key = process.env.RESEND_API_KEY;
  const from = process.env.FROM_EMAIL;
  if (!key || !from || !email) return false;
  const r = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      from,
      to: [email],
      subject: `Your Crypto Market Intelligence ${product.name} access`,
      html: `<h2>Payment confirmed</h2><p>Your <strong>${product.name}</strong> purchase is confirmed.</p><p><a href="${downloadUrl}">Download your ${product.leads.toLocaleString('en-US')} leads</a></p><p><a href="${dashboardUrl}">Open your CMI dashboard</a></p><p>Shoppex order: ${orderId}</p>`
    })
  });
  return r.ok;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ ok: false, error: 'method_not_allowed' });
  try {
    const raw = getRawBody(req);
    verifyWebhook(req, raw);
    const body = typeof req.body === 'object' ? req.body : JSON.parse(raw || '{}');
    const event = String(body.event || body.type || body.name || body.data?.event || '').toLowerCase();
    if (event && !['order:paid', 'order.paid', 'order_paid', 'paid'].includes(event)) return res.status(200).json({ ok: true, ignored: event });

    const orderId = findOrderId(body);
    if (!orderId) return res.status(400).json({ ok: false, error: 'missing_order_id' });
    const order = await getOrder(orderId);
    const paymentStatus = String(order.payment_status || order.paymentStatus || order.status || '').toUpperCase();
    if (!['PAID', 'COMPLETED'].includes(paymentStatus)) return res.status(200).json({ ok: true, pending: paymentStatus || 'UNKNOWN' });

    const productKey = findProduct(order);
    const product = PRODUCTS[productKey];
    const email = safeEmail(order.customer_email || order.customerEmail || body.customer_email || body.email || '');
    if (!product) return res.status(400).json({ ok: false, error: 'unknown_product' });

    const base = (process.env.APP_BASE_URL || 'https://cryptomarketintelligence.pro').replace(/\/$/, '');
    const access = signPayload({ product: productKey, email, payment_id: order.uniqid || order.id || orderId, payment_verified: true, provider: 'shoppex', iat: Date.now(), exp: Date.now() + 30*24*60*60*1000 });
    const downloadUrl = `${base}/api/download?token=${encodeURIComponent(access)}`;
    const dashboardUrl = `${base}/dashboard.html?token=${encodeURIComponent(access)}`;
    let emailed = false;
    await recordOrder({provider:'shoppex',payment_id:order.uniqid || order.id || orderId,order_id:order.uniqid || order.id || orderId,product:productKey,leads:product.leads,amount:order.total || order.amount || null,currency:order.currency || 'EUR',email,payment_status:'PAID',delivery_status:'ready'});
    try { emailed = await sendEmail(email, product, order.uniqid || order.id || orderId, downloadUrl, dashboardUrl); } catch {}
    await updateOrder('shoppex', order.uniqid || order.id || orderId, { email_status: emailed ? 'sent' : 'skipped' });

    return res.status(200).json({ ok: true, order_id: order.uniqid || order.id || orderId, product: productKey, leads: product.leads, download_url: downloadUrl, dashboard_url: dashboardUrl, emailed });
  } catch (error) {
    return res.status(400).json({ ok: false, error: error instanceof Error ? error.message : String(error) });
  }
}
