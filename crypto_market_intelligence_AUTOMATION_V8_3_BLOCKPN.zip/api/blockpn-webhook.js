import crypto from 'node:crypto';
import { PRODUCTS, safeEmail, signPayload } from './_lib.js';
import { recordOrder } from './_db.js';

export const config = { api: { bodyParser: false } };

function rawBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c)));
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function verifySignature(req, raw) {
  const secret = process.env.BLOCKPN_WEBHOOK_SECRET;
  if (!secret) throw new Error('BLOCKPN_WEBHOOK_SECRET is not configured');
  const signature = String(req.headers['x-signature'] || '').trim();
  const timestamp = Number(req.headers['x-webhook-timestamp'] || 0);
  const age = Math.abs(Date.now() / 1000 - timestamp);
  if (!signature || !Number.isFinite(timestamp) || age > 300) throw new Error('Invalid or expired Blockpn webhook signature');
  const expected = 'sha256=' + crypto.createHmac('sha256', secret).update(raw, 'utf8').digest('hex');
  if (signature.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) throw new Error('Invalid Blockpn webhook signature');
}

function paymentObject(body) { return body?.payment || body?.data?.payment || body?.data || body || {}; }
function metadataOf(payment) { let m = payment?.metadata || {}; if (typeof m === 'string') { try { m = JSON.parse(m); } catch { m = {}; } } return m || {}; }

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ ok:false, error:'method_not_allowed' });
  try {
    const raw = await rawBody(req);
    verifySignature(req, raw);
    const body = JSON.parse(raw || '{}');
    const event = String(req.headers['x-event-type'] || body.event || body.type || '').toLowerCase();
    if (event && event !== 'payment.paid') return res.status(200).json({ ok:true, ignored:event });

    const payment = paymentObject(body);
    const status = String(payment.status || body.status || '').toLowerCase();
    if (status !== 'paid') return res.status(200).json({ ok:true, pending:status || 'unknown' });

    const metadata = metadataOf(payment);
    const key = String(metadata.product || '').trim().toLowerCase();
    const product = PRODUCTS[key];
    if (!product) return res.status(400).json({ ok:false, error:'unknown_product' });
    const email = safeEmail(metadata.email || payment.customer_email || payment.email || body.customer_email || '');
    if (!email) return res.status(400).json({ ok:false, error:'missing_customer_email' });

    const paymentId = String(payment.id || body.payment_id || body.id || '').trim();
    if (!paymentId) return res.status(400).json({ ok:false, error:'missing_payment_id' });
    const base = (process.env.APP_BASE_URL || 'https://cryptomarketintelligence.pro').replace(/\/$/, '');
    const access = signPayload({ product:key, email, payment_id:paymentId, payment_verified:true, provider:'blockpn', iat:Date.now(), exp:Date.now()+30*24*60*60*1000 });
    const downloadUrl = `${base}/api/download?token=${encodeURIComponent(access)}`;
    const dashboardUrl = `${base}/dashboard.html?token=${encodeURIComponent(access)}`;
    await recordOrder({ provider:'blockpn', payment_id:paymentId, order_id:String(metadata.order || metadata.order_id || payment.reference || body.event_id || ''), product:key, leads:product.leads, amount:payment.amount || product.amount, currency:payment.currency || 'EUR', email, payment_status:'PAID', delivery_status:'ready' });
    return res.status(200).json({ ok:true, provider:'blockpn', payment_id:paymentId, product:key, leads:product.leads, download_url:downloadUrl, dashboard_url:dashboardUrl });
  } catch (error) {
    return res.status(400).json({ ok:false, error:error instanceof Error ? error.message : String(error) });
  }
}
