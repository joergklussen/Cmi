# CMI V8 Setup — Shoppex API + Dynamic Delivery

V8 uses the Shoppex Developer API and Dynamic Product Delivery.

## Required Vercel variables

- `APP_BASE_URL=https://cryptomarketintelligence.pro`
- `ORDER_SECRET=<existing CMI secret>`
- `ADMIN_KEY=<existing admin key>`
- `SHOPPEX_API_KEY=<Shoppex Developer API key>`
- `DATABASE_URL=<Neon/Postgres connection string>`

Do not put Shoppex secrets or API keys in the repository.

## One-click Shoppex synchronization

After deployment, sign into `/admin.html` and click **Sync Shoppex**.

CMI then:
1. Lists the shop's products through the Shoppex Developer API.
2. Matches the five CMI products by title.
3. Creates missing products.
4. Converts the five CMI products to `DYNAMIC`.
5. Sets `dynamic_webhook` to:
   `https://cryptomarketintelligence.pro/api/shoppex-dynamic`
6. Sets a deterministic per-product `dynamic_webhook_secret`, derived from the existing `ORDER_SECRET` and the Shoppex product ID.
7. Sets `metadata.cmi_product_key` and `metadata.cmi_leads`.
8. Limits quantity to one package per order.

This intentionally replaces Shoppex-generated dynamic secrets for the five CMI products with CMI-controlled per-product secrets. The five products therefore remain separately signed while no secret has to be copied into Vercel.

## Dynamic delivery

Shoppex sends `POST` requests to `/api/shoppex-dynamic`. The handler verifies:

- `X-Shoppex-Signature-V2`
- `X-Shoppex-Timestamp`
- `X-Shoppex-Delivery-Id`
- the product-specific HMAC-SHA256 secret
- a 5-minute timestamp window
- `X-Shoppex-Idempotency-Key`

The same idempotency key returns the same delivery token rather than generating a second entitlement.

Shoppex documents this Dynamic Delivery contract and the `X-Shoppex-Signature-V2` format in its developer docs.
