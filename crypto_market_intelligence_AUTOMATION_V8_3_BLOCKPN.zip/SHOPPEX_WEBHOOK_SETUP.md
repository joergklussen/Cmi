# Shoppex → CMI automatic lead delivery

Webhook endpoint:
`https://cryptomarketintelligence.pro/api/shoppex-webhook`

Shoppex should send the `order:paid` event to this endpoint. CMI then re-reads the order from Shoppex using the server-side API key, checks that the payment is actually paid/completed, maps the purchased product to the exact lead package, creates a signed 30-day download token, and can email the download link through Resend.

## Product mapping

- Test / Crypto Lead Test Pack → 100 leads → `data/leads_100.csv.gz`
- Starter / Crypto Lead Starter Pack → 1,000 leads → `data/leads_1000.csv.gz`
- Advanced / Crypto Lead Advanced Pack → 10,000 leads → `data/leads_10000.csv.gz`
- Pro / Crypto Lead Pro Pack → 25,000 leads → `data/leads_25000.csv.gz`
- Business / Crypto Lead Business Database → 115,000 leads → `data/leads_115000.csv.gz`

## Vercel environment variables

Required:

- `APP_BASE_URL=https://cryptomarketintelligence.pro`
- `ORDER_SECRET=<long random secret>`
- `SHOPPEX_API_KEY=<Shoppex developer API key>`
- `SHOPPEX_WEBHOOK_SECRET=<the secret for the primary webhook>`
- `SHOPPEX_WEBHOOK_SECRETS=<optional comma-separated additional webhook secrets>`

Optional email delivery:

- `RESEND_API_KEY=<Resend API key>`
- `FROM_EMAIL=<verified sender address>`

Never put either Shoppex secret in frontend JavaScript or HTML.

## Shoppex setup

1. Open Shoppex Dashboard → Settings → API and create a scoped API key with permission to read orders.
2. Open Shoppex → Developers/API → Webhooks and create a webhook for `order:paid`.
3. Set the URL to `https://cryptomarketintelligence.pro/api/shoppex-webhook`.
4. Copy the webhook signing secret into Vercel as `SHOPPEX_WEBHOOK_SECRET`. If you created multiple Shoppex webhooks with different signing secrets, put the additional secrets in `SHOPPEX_WEBHOOK_SECRETS`, separated by commas. You do not need one Vercel function per product.
5. Add `SHOPPEX_API_KEY` to Vercel Environment Variables.
6. Redeploy the Vercel project.
7. Test with a real low-value/test order and verify the webhook delivery log plus the generated download.

Shoppex supports signed webhooks and retries failed deliveries; the API also exposes order details including customer email, payment status, and product line items.
