# CMI Automation V8

V8 turns the payment/delivery loop into a durable sales system while preserving V7's payment verification and protected file delivery.

## Added
- Neon/Postgres persistence for paid orders
- Idempotent order upsert by `(provider, payment_id)`
- Customer email, product, lead count, amount, payment status
- Delivery and email state
- Download counter
- Product and revenue analytics
- Private `/admin.html` control center
- 8-hour signed admin sessions (raw ADMIN_KEY is not stored client-side)
- `/api/admin` login + statistics endpoint
- `/api/_db.js` persistence layer
- V8 setup documentation

## Payment routes
Mollie, PayLio, Shoppex and BTCPay/direct crypto remain supported. Existing payment secrets stay server-side.

## Important
Persistence requires `DATABASE_URL` (or `POSTGRES_URL`) and admin analytics require `ADMIN_KEY`. Without them, the existing V7-style payment and delivery flow remains usable, but database history and admin analytics are unavailable.
