import { PRODUCTS, verifyPayload } from './_lib.js';

export default async function handler(req, res) {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'private, no-store');
  try {
    const token = new URL(req.url, `https://${req.headers.host || 'cryptomarketintelligence.pro'}`).searchParams.get('token');
    const p = verifyPayload(token);
    const product = PRODUCTS[p.product];
    if (!product || p.payment_verified !== true) throw new Error('Access denied');
    return res.status(200).json({ ok: true, product: p.product, product_name: product.name, leads: product.leads, email: p.email, payment_id: p.payment_id, expires_at: p.exp });
  } catch {
    return res.status(403).json({ ok: false, error: 'invalid_or_expired_access' });
  }
}
