import { PRODUCTS, normalizeProduct, safeEmail, signPayload } from './_lib.js';

const ADDRESSES = {
  BTC: '17vfxCFP6cEwL1cQPnZ4cG8rakujH9H1c2',
  ETH: '0x4d418536aabd50ddaac84c2099a5faa3b926e1d8',
  USDT_TRON: 'TY85hDmbYDNV7VBPEDhxzzqrLqZhjywb6B',
  SOL: '4wwKKaazydRt8GvCy4YRhYyRXSVDa3r1UMpEVgVKWwP7'
};

const DECIMALS = { BTC: 8, ETH: 8, USDT_TRON: 6, SOL: 8 };
const COINGECKO = { BTC:'bitcoin', ETH:'ethereum', SOL:'solana' };

function json(res,status,body){res.status(status).setHeader('Content-Type','application/json; charset=utf-8');res.setHeader('Cache-Control','no-store');return res.json(body);}
function roundUp(v,d){const p=10**d; return Math.ceil(v*p)/p;}
async function priceEUR(asset){
  const overrides=process.env.CRYPTO_PRICES_EUR_JSON;
  if(overrides){try{const x=JSON.parse(overrides); if(Number(x[asset])>0)return Number(x[asset]);}catch{}}
  if(asset==='USDT_TRON') return 1;
  const id=COINGECKO[asset];
  const r=await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${id}&vs_currencies=eur`,{headers:{Accept:'application/json'}});
  const d=await r.json().catch(()=>({})); const p=Number(d?.[id]?.eur); if(!r.ok||!p) throw new Error('Unable to obtain the current crypto/EUR price.'); return p;
}

export default async function handler(req,res){
  if(req.method!=='GET') return json(res,405,{error:'method_not_allowed'});
  try{
    const u=new URL(req.url,`https://${req.headers.host||'cryptomarketintelligence.pro'}`);
    const productKey=normalizeProduct(u.searchParams.get('product')); const email=safeEmail(u.searchParams.get('email')); const asset=String(u.searchParams.get('asset')||'').toUpperCase();
    if(!productKey) return json(res,400,{error:'invalid_product'}); if(!email) return json(res,400,{error:'email_required'}); if(!ADDRESSES[asset]) return json(res,400,{error:'unsupported_asset'});
    const product=PRODUCTS[productKey]; const eur=Number(product.amount); const p=await priceEUR(asset);
    const uniqueBump = asset==='USDT_TRON' ? 0.01 : (asset==='BTC'?0.00000001:asset==='ETH'?0.00000001:0.00000001);
    const amount=roundUp(eur/p,DECIMALS[asset])+uniqueBump;
    const order=signPayload({kind:'direct_crypto',product:productKey,email,asset,amount:String(amount),iat:Date.now(),exp:Date.now()+30*60*1000});
    const base=(process.env.APP_BASE_URL||'https://cryptomarketintelligence.pro').replace(/\/$/,'');
    return json(res,200,{order,product:productKey,name:product.name,eur:product.amount,asset,amount:String(amount),address:ADDRESSES[asset],expiresAt:Date.now()+30*60*1000,statusUrl:`${base}/api/crypto-status?order=${encodeURIComponent(order)}`});
  }catch(e){return json(res,502,{error:'crypto_quote_failed',message:e instanceof Error?e.message:String(e)});}
}
