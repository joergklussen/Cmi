import { PRODUCTS, verifyPayload, signPayload } from './_lib.js';

function html(res, status, body) {
  res.status(status).setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(body);
}
function esc(s='') { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

async function sendEmail(email, product, paymentId, downloadUrl, dashboardUrl) {
  const key = process.env.RESEND_API_KEY;
  const from = process.env.FROM_EMAIL;
  if (!key || !from || !email) return { sent: false, skipped: true };
  const r = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from, to: [email], subject: `Your Crypto Market Intelligence ${product.name} access`, html: `<h2>Payment confirmed</h2><p>Your <strong>${esc(product.name)}</strong> purchase is confirmed.</p><p><a href="${downloadUrl}">Download your CSV</a></p><p><a href="${dashboardUrl}">Open your CMI dashboard</a></p><p>Payment ID: ${esc(paymentId)}</p><p>Please use the data only in accordance with applicable privacy, marketing and platform rules.</p>` })
  });
  return { sent: r.ok };
}

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).send('Method not allowed.');
  try {
    const url = new URL(req.url, `https://${req.headers.host || 'cryptomarketintelligence.pro'}`);
    const order = verifyPayload(url.searchParams.get('order'));
    const product = PRODUCTS[order.product];
    if (!product) return res.status(400).send('Invalid product.');
    const token = (url.searchParams.get('ipn_token') || '').trim();
    const paymentId = (url.searchParams.get('payment_id') || '').trim();
    if (!token && !paymentId) return res.status(400).send('Missing PayLio payment reference.');
    const apiKey = process.env.PAYLIO_API_KEY;
    if (!apiKey) return res.status(503).send('PayLio is not configured.');
    const q = new URLSearchParams(token ? { ipn_token: token } : { payment_id: paymentId });
    const upstream = await fetch(`https://paylio.org/api/v1/payment-status?${q.toString()}`, { headers: { Authorization: `Bearer ${apiKey}`, Accept: 'application/json' } });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return res.status(502).send('Unable to verify payment with PayLio.');
    if (data.status !== 'paid' || data.forward_status !== 'completed') return res.status(400).send('Payment has not been fully confirmed yet.');

    const finalPaymentId = data.payment_id || paymentId || 'confirmed';
    const access = signPayload({ product: order.product, email: order.email, payment_id: finalPaymentId, payment_verified: true, iat: Date.now(), exp: Date.now() + 30*24*60*60*1000 });
    const base = (process.env.APP_BASE_URL || 'https://cryptomarketintelligence.pro').replace(/\/$/, '');
    const downloadUrl = `${base}/api/download?token=${encodeURIComponent(access)}`;
    const dashboardUrl = `${base}/dashboard.html?token=${encodeURIComponent(access)}`;
    let mail = { sent: false, skipped: true };
    try { mail = await sendEmail(order.email, product, finalPaymentId, downloadUrl, dashboardUrl); } catch {}

    return html(res, 200, `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Payment confirmed | Crypto Market Intelligence</title><link rel="stylesheet" href="/styles.css"></head><body><main class="section"><div class="wrap card" style="max-width:760px;margin:8rem auto;text-align:center"><span class="eyebrow">Payment confirmed</span><h1>Thank you — your access is ready.</h1><p class="lead">${esc(product.name)} · ${product.leads.toLocaleString('en-US')} leads</p><p><a class="btn dark" href="${downloadUrl}">Download your CSV</a></p><p><a class="btn" href="${dashboardUrl}">Open dashboard</a></p><p class="muted">${mail.sent ? 'A delivery email has also been sent to your purchasing email address.' : 'Keep this page or use the download button now. Email delivery will be enabled when the mail service is configured.'}</p><p class="small muted">Payment ID: ${esc(finalPaymentId)}</p></div></main></body></html>`);
  } catch (error) {
    return res.status(400).send(`Unable to verify payment: ${esc(error instanceof Error ? error.message : String(error))}`);
  }
}
