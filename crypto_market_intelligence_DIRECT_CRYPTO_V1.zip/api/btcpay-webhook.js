import crypto from 'node:crypto';
function rawBody(req){ if(typeof req.body==='string') return req.body; if(Buffer.isBuffer(req.body)) return req.body.toString('utf8'); return JSON.stringify(req.body||{}); }
export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).send('Method not allowed.');
  const secret=process.env.BTCPAY_WEBHOOK_SECRET;
  if(!secret) return res.status(503).send('BTCPAY_WEBHOOK_SECRET is not configured.');
  const body=rawBody(req); const sig=req.headers['btcpay-sig']||''; const expected='sha256='+crypto.createHmac('sha256',secret).update(body).digest('hex');
  if(!crypto.timingSafeEqual(Buffer.from(String(sig)),Buffer.from(expected))) return res.status(401).send('Invalid signature.');
  return res.status(200).json({received:true});
}
