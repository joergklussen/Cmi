import { PRODUCTS, safeEmail, signPayload } from './_lib.js';

function esc(s='') { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

async function getPayment(id) {
  const key = process.env.MOLLIE_API_KEY;
  const r = await fetch(`https://api.mollie.com/v2/payments/${encodeURIComponent(id)}`, {
    headers: { Authorization: `Bearer ${key}`, Accept: 'application/json' }
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`Mollie payment lookup failed (${r.status})`);
  return data;
}

export default async function handler(req, res) {
  try {
    const url = new URL(req.url, `https://${req.headers.host || 'cryptomarketintelligence.pro'}`);
    const id = (url.searchParams.get('id') || url.searchParams.get('paymentId') || url.searchParams.get('payment_id') || '').trim();
    if (!id) return res.status(400).send('Missing payment ID. Please return to the shop and start checkout again.');
    if (!process.env.MOLLIE_API_KEY || !process.env.ORDER_SECRET) return res.status(503).send('Mollie is not configured.');

    const payment = await getPayment(id);
    let metadata = payment.metadata || {};
    if (typeof metadata === 'string') { try { metadata = JSON.parse(metadata); } catch { metadata = {}; } }
    const productKey = String(metadata.product || '').trim().toLowerCase();
    const email = safeEmail(metadata.email || '');
    const product = PRODUCTS[productKey];
    if (!product || !email) return res.status(400).send('Invalid payment metadata.');

    if (payment.status !== 'paid') {
      const status = esc(payment.status || 'pending');
      res.setHeader('Cache-Control', 'no-store');
      return res.status(200).send(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Payment status | Crypto Market Intelligence</title><link rel="stylesheet" href="/styles.css"></head><body><main class="section"><div class="wrap card" style="max-width:760px;margin:8rem auto;text-align:center"><span class="eyebrow">Payment status</span><h1>Your payment is ${status}.</h1><p class="lead">We will only release your product after Mollie confirms the payment.</p><p><a class="btn dark" href="/products">Back to products</a></p></div></main></body></html>`);
    }

    const base = (process.env.APP_BASE_URL || 'https://cryptomarketintelligence.pro').replace(/\/$/, '');
    const access = signPayload({ product: productKey, email, payment_id: payment.id, payment_verified: true, provider: 'mollie', iat: Date.now(), exp: Date.now() + 30*24*60*60*1000 });
    const downloadUrl = `${base}/api/download?token=${encodeURIComponent(access)}`;
    const dashboardUrl = `${base}/dashboard.html?token=${encodeURIComponent(access)}`;
    res.setHeader('Cache-Control', 'no-store');
    return res.status(200).send(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Payment confirmed | Crypto Market Intelligence</title><link rel="stylesheet" href="/styles.css"></head><body><main class="section"><div class="wrap card" style="max-width:760px;margin:8rem auto;text-align:center"><span class="eyebrow">Payment confirmed</span><h1>Thank you — your access is ready.</h1><p class="lead">${esc(product.name)} · ${product.leads.toLocaleString('en-US')} leads</p><p><a class="btn dark" href="${downloadUrl}">Download your CSV</a></p><p><a class="btn" href="${dashboardUrl}">Open dashboard</a></p><p class="muted">A secure download token has been generated for your purchase.</p><p class="small muted">Mollie payment: ${esc(payment.id)}</p></div></main></body></html>`);
  } catch (error) {
    return res.status(400).send(`Unable to verify payment: ${esc(error instanceof Error ? error.message : String(error))}`);
  }
}
