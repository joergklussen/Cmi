import { PRODUCTS, verifyPayload, signPayload } from './_lib.js';
function esc(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;"}[c]));}
export default async function handler(req,res){
  if(req.method!=='GET') return res.status(405).send('Method not allowed.');
  try{
    const url=new URL(req.url,`https://${req.headers.host||'cryptomarketintelligence.pro'}`);
    const order=verifyPayload(url.searchParams.get('order')); const product=PRODUCTS[order.product];
    if(!product) return res.status(400).send('Invalid product.');
    const instance=(process.env.BTCPAY_INSTANCE||'').replace(/\/$/,''); const storeId=process.env.BTCPAY_STORE_ID; const apiKey=process.env.BTCPAY_API_KEY;
    if(!instance||!storeId||!apiKey) return res.status(503).send('BTCPay is not configured.');
    let invoiceId=url.searchParams.get('invoiceId')||url.searchParams.get('invoice_id')||'';
    if(!invoiceId){
      const list=await fetch(`${instance}/api/v1/stores/${encodeURIComponent(storeId)}/invoices?orderId=${encodeURIComponent(order)}`,{headers:{Authorization:`token ${apiKey}`,Accept:'application/json'}});
      const arr=await list.json().catch(()=>[]); if(Array.isArray(arr)&&arr[0]) invoiceId=arr[0].id;
    }
    if(!invoiceId) return res.status(400).send('Missing BTCPay invoice ID.');
    const r=await fetch(`${instance}/api/v1/stores/${encodeURIComponent(storeId)}/invoices/${encodeURIComponent(invoiceId)}`,{headers:{Authorization:`token ${apiKey}`,Accept:'application/json'}});
    const inv=await r.json().catch(()=>({})); if(!r.ok) return res.status(502).send('Unable to verify BTCPay payment.');
    if(!['Settled','Complete'].includes(inv.status)) return res.status(202).send(`Payment status: ${esc(inv.status||'Pending')}. Please return after the payment is confirmed.`);
    const access=signPayload({product:order.product,email:order.email,payment_id:invoiceId,payment_verified:true,provider:'btcpay',iat:Date.now(),exp:Date.now()+30*24*60*60*1000});
    const download=`${(process.env.APP_BASE_URL||'https://cryptomarketintelligence.pro').replace(/\/$/,'')}/api/download?token=${encodeURIComponent(access)}`;
    const dash=`${(process.env.APP_BASE_URL||'https://cryptomarketintelligence.pro').replace(/\/$/,'')}/dashboard.html?token=${encodeURIComponent(access)}`;
    res.setHeader('Content-Type','text/html; charset=utf-8'); res.setHeader('Cache-Control','no-store');
    return res.status(200).send(`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Crypto payment confirmed</title><link rel="stylesheet" href="/styles.css"></head><body><main class="section"><div class="wrap card" style="max-width:760px;margin:8rem auto;text-align:center"><span class="eyebrow">Crypto payment confirmed</span><h1>Your access is ready.</h1><p class="lead">${esc(product.name)} · ${product.leads.toLocaleString('en-US')} leads</p><p><a class="btn dark" href="${download}">Download your CSV</a></p><p><a class="btn" href="${dash}">Open dashboard</a></p><p class="small muted">BTCPay invoice: ${esc(invoiceId)}</p></div></main></body></html>`);
  }catch(e){return res.status(400).send(`Unable to verify crypto payment: ${esc(e instanceof Error?e.message:String(e))}`);}
}
