import { PRODUCTS, safeEmail, signPayload } from './_lib.js';

function esc(s='') { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

async function getPayment(id) {
  const key = process.env.MOLLIE_API_KEY;
  const r = await fetch(`https://api.mollie.com/v2/payments/${encodeURIComponent(id)}`, {
    headers: { Authorization: `Bearer ${key}`, Accept: 'application/json' }
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`Mollie payment lookup failed (${r.status})`);
  return data;
}

async function sendEmail(email, product, paymentId, downloadUrl, dashboardUrl) {
  const key = process.env.RESEND_API_KEY;
  const from = process.env.FROM_EMAIL;
  if (!key || !from || !email) return false;
  const r = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      from,
      to: [email],
      subject: `Your Crypto Market Intelligence ${product.name} access`,
      html: `<h2>Payment confirmed</h2><p>Your <strong>${esc(product.name)}</strong> purchase is confirmed.</p><p><a href="${downloadUrl}">Download your CSV</a></p><p><a href="${dashboardUrl}">Open your CMI dashboard</a></p><p>Payment ID: ${esc(paymentId)}</p>`
    })
  });
  return r.ok;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).send('Method not allowed.');
  try {
    const key = process.env.MOLLIE_API_KEY;
    if (!key || !process.env.ORDER_SECRET) return res.status(503).send('Mollie is not configured.');

    let paymentId = '';
    if (typeof req.body === 'string') paymentId = new URLSearchParams(req.body).get('id') || '';
    else if (req.body && typeof req.body === 'object') paymentId = req.body.id || '';
    if (!paymentId) paymentId = new URLSearchParams(req.url.split('?')[1] || '').get('id') || '';
    if (!paymentId) return res.status(400).send('Missing Mollie payment id.');

    const payment = await getPayment(paymentId);
    let metadata = payment.metadata || {};
    if (typeof metadata === 'string') { try { metadata = JSON.parse(metadata); } catch { metadata = {}; } }
    const productKey = String(metadata.product || '').trim().toLowerCase();
    const email = safeEmail(metadata.email || '');
    const product = PRODUCTS[productKey];
    if (!product || !email) return res.status(400).send('Invalid payment metadata.');

    if (payment.status !== 'paid') return res.status(200).send('OK');

    const base = (process.env.APP_BASE_URL || 'https://cryptomarketintelligence.pro').replace(/\/$/, '');
    const access = signPayload({ product: productKey, email, payment_id: payment.id, payment_verified: true, provider: 'mollie', iat: Date.now(), exp: Date.now() + 30*24*60*60*1000 });
    const downloadUrl = `${base}/api/download?token=${encodeURIComponent(access)}`;
    const dashboardUrl = `${base}/dashboard.html?token=${encodeURIComponent(access)}`;
    try { await sendEmail(email, product, payment.id, downloadUrl, dashboardUrl); } catch {}

    return res.status(200).send('OK');
  } catch (error) {
    return res.status(500).send(`Webhook error: ${error instanceof Error ? error.message : String(error)}`);
  }
}
