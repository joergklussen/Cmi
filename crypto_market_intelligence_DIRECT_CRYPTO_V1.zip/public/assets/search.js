(() => {
  const boot = async () => {
    const nav = document.querySelector('.navlinks');
    if (!nav || document.querySelector('.site-search')) return;
    const box = document.createElement('div');
    box.className = 'site-search';
    box.innerHTML = '<button class="search-toggle" type="button" aria-label="Open site search">⌕</button><form class="search-form" role="search"><input class="search-input" type="search" placeholder="Search site…" aria-label="Search site"><div class="search-results" role="listbox" aria-label="Search results"></div></form>';
    nav.appendChild(box);
    const input = box.querySelector('.search-input');
    const form = box.querySelector('.search-form');
    const results = box.querySelector('.search-results');
    const toggle = box.querySelector('.search-toggle');
    let index = [];
    try { index = await fetch('/assets/search-index.json', {cache:'no-store'}).then(r => r.ok ? r.json() : []); } catch (_) {}
    const render = (q) => {
      const term = q.trim().toLowerCase();
      if (!term) { results.innerHTML = ''; results.hidden = true; return; }
      const words = term.split(/\s+/).filter(Boolean);
      const matches = index.map(item => {
        const hay = (item.title + ' ' + item.description + ' ' + item.text).toLowerCase();
        const score = words.reduce((s,w) => s + (hay.includes(w) ? (item.title.toLowerCase().includes(w) ? 5 : 1) : 0), 0);
        return {...item, score};
      }).filter(x => x.score > 0).sort((a,b)=>b.score-a.score).slice(0,8);
      results.innerHTML = matches.length ? matches.map(item => `<a class="search-result" href="${item.url}"><strong>${escapeHtml(item.title)}</strong><span>${escapeHtml(item.description || item.text.slice(0,150))}</span></a>`).join('') : '<div class="search-empty">No matching page found.</div>';
      results.hidden = false;
    };
    input.addEventListener('input', () => render(input.value));
    form.addEventListener('submit', e => { e.preventDefault(); const first = results.querySelector('a'); if (first) window.location.href = first.href; });
    toggle.addEventListener('click', () => { box.classList.toggle('open'); if (box.classList.contains('open')) input.focus(); });
    document.addEventListener('click', e => { if (!box.contains(e.target)) { results.hidden = true; } });
    function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
