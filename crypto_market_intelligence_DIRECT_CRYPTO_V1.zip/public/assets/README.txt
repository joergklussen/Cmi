Brand assets integrated into the Crypto Market Intelligence Netlify deploy.
logo.png = brand lockup
signal-report.png = Signal Report product visual
pro.png = Pro Access product visual
business.png = Business Suite product visual
brand-preview.png = full visual reference
